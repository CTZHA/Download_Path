﻿Configuration NodeConfig {
    Import-DscResource -ModuleName PsDesiredStateConfiguration

    Node 'localhost' {
        Script AntivirusExclusion
        {
            GetScript = 
            {
				return @{ 'Result' = "OK" }
            }

            SetScript = 
            {
                Add-MpPreference -ExclusionPath "C:\ProgramData\docker"
				Add-MpPreference -ExclusionPath "C:\Program Files\Docker"
				fsutil 8dot3name set 1
				fsutil 8dot3name strip /s /f C:\
            }

            TestScript = 
            {
				return $false
            }
        }
    }
} 